import React, { useState } from 'react';

const faqs = [
  {
    question: 'What is Lorem Ipsum?',
    answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.',
  },
  {
    question: 'How we can buy and invest in NFT?',
    answer: 'You can buy and invest in NFTs through online marketplaces like OpenSea and Rarible.',
  },
  {
    question: 'Where does it come from?',
    answer: 'Contrary to popular belief, Lorem Ipsum is not simply random text.',
  },
];

const FAQSection = () => {
  const [activeIndex, setActiveIndex] = useState(null);

  const toggleFAQ = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <div id="faq" className="bg-gray-950 text-white py-10 px-6">

       <div className="flex justify-center items-center mb-8 mt-20">

       <div className="h-1 w-8 bg-blue-500"></div>
        <h2 className="text-blue-500 text-lg font-extrabold uppercase tracking-wide ml-2 mr-2">QUESTIONS & ANSWERS 
        </h2>
        <div className="h-1 w-8 bg-blue-500"></div>
      </div>

      <h2 className="text-center text-4xl font-extrabold mb-10">FREQUENTLY ASKED QUESTIONS</h2>
      <div className="max-w-4xl mx-auto">
        {faqs.map((faq, index) => (
          <div key={index} className="bg-[#1c1f23] rounded-md mb-4">
            <button 
              onClick={() => toggleFAQ(index)} 
              className="w-full flex justify-between items-center p-4 text-left text-lg font-medium text-gray-300 hover:text-white">
              <span>{faq.question}</span>
              <span className="text-gray-500">{activeIndex === index ? '-' : '+'}</span>
            </button>
            {activeIndex === index && (
              <div className="px-4 pb-4 text-gray-400">
                {faq.answer}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQSection;
